**A simple implementation of collisions of balls involving conservation of momentum in html5**

Check out the live demo [here](http://home.iitk.ac.in/~gopi/HTML5-Canvas-Balls-Collision/)
